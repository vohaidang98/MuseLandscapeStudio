"""Error hierarchy. Every error maps to an HTTP status and an OpenAI-style error body."""

from __future__ import annotations

from typing import Any


class Muse2APIError(Exception):
    status_code: int = 500
    error_type: str = "server_error"
    code: str = "internal_error"

    def __init__(self, message: str = "", *, code: str | None = None) -> None:
        super().__init__(message or self.__class__.__name__)
        self.message = message or self.__class__.__name__
        if code:
            self.code = code

    def to_body(self) -> dict[str, Any]:
        return {"error": {"message": self.message, "type": self.error_type, "code": self.code}}


# --- client side ---
class InvalidRequest(Muse2APIError):
    status_code = 400
    error_type = "invalid_request_error"
    code = "invalid_request"


class Unauthorized(Muse2APIError):
    status_code = 401
    error_type = "authentication_error"
    code = "invalid_api_key"


class InsufficientBalance(Muse2APIError):
    """The key's prepaid credit does not cover the request. 402 rather than 429,
    which OpenAI SDKs retry automatically."""

    status_code = 402
    error_type = "insufficient_quota"
    code = "insufficient_balance"


class TooManyRequests(Muse2APIError):
    status_code = 429
    error_type = "rate_limit_error"
    code = "rate_limited"


class Forbidden(Muse2APIError):
    status_code = 403
    error_type = "permission_error"
    code = "forbidden"


class NotFound(Muse2APIError):
    status_code = 404
    error_type = "invalid_request_error"
    code = "not_found"


class FeatureNotImplemented(Muse2APIError):
    """Reserved endpoint or driver capability that has not been built yet."""

    status_code = 501
    error_type = "not_implemented"
    code = "not_implemented"


# --- payments (/billing) ---
class CheckoutUnavailable(Muse2APIError):
    status_code = 503
    error_type = "server_error"
    code = "checkout_unavailable"


class PaymentError(Muse2APIError):
    """PayPal failed, or a payment did not match what was ordered."""

    status_code = 502
    error_type = "payment_error"
    code = "payment_error"


# --- capacity ---
class NoAccountAvailable(Muse2APIError):
    status_code = 503
    error_type = "server_error"
    code = "no_account_available"


# --- upstream (muse.ai) ---
class UpstreamError(Muse2APIError):
    """Generic upstream failure. ``retryable`` tells the service layer whether to fail over."""

    status_code = 502
    error_type = "upstream_error"
    code = "upstream_error"
    retryable: bool = True


class UpstreamAuthError(UpstreamError):
    """The account's session is invalid; the account should be marked invalid."""

    code = "upstream_auth_failed"


class UpstreamQuotaError(UpstreamError):
    """The account ran out of quota; the account should cool down."""

    status_code = 429
    code = "upstream_quota_exhausted"


class UpstreamTimeout(UpstreamError):
    status_code = 504
    code = "upstream_timeout"


class UpstreamGlitch(UpstreamError):
    """muse.ai's agent failed mid-turn ("Sorry, I ran into a problem..."); another try usually works."""

    code = "upstream_glitch"


class UpstreamRefused(UpstreamError):
    """Upstream answered but did not produce what was asked (e.g. text instead of an image)."""

    code = "upstream_refused"
    retryable = False


def quota_reply(text: str) -> bool:
    """Explicit exhaustion in a current assistant reply, never the sidebar."""
    import re
    low = text.lower().replace("’", "'")
    low = re.sub(r'[\u200e\u200f\u2066-\u2069]', '', low)
    low = re.sub(r'[\u2010-\u2015\u2212]', '-', low)
    low = ' '.join(low.split())
    phrases = ('out of credits', 'usage limit reached', 'budget limit reached',
               'daily limit reached', 'video limit reached', 'video budget exhausted',
               'quota exceeded', 'quota exhausted', 'out of quota', 'token limit reached')
    subject = r"(?:daily |24[ -]hour |video |generation |usage |weekly |account |token |credit ){1,4}(?:limit|quota|budget)"
    return any(p in low for p in phrases) or bool(re.search(
        r"(?:reached|exceeded|used up|hit) (?:your |the |its )?(?:daily |24.hour |video |generation |usage |weekly |account |token ){0,4}(?:limit|quota|budget)", low)) or bool(re.search(
        subject + r" (?:is |has been |was )?(?:still |already )?(?:in place|active|reached|exceeded|exhausted|used up)", low)) or bool(re.search(
        r"(?:blocked|limited) by (?:your |the )?" + subject, low))
