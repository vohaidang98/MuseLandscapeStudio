"""Durable JSON snapshots with one known-good backup."""
import json
import os
import shutil
import tempfile
import uuid
from pathlib import Path


def _replace(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.json-', suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(name, 0o600)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def durable_write(path, payload):
    path = Path(path)
    json.loads(payload)
    if path.is_file():
        try:
            previous = path.read_text(encoding='utf-8-sig')
            json.loads(previous)
        except (ValueError, UnicodeError):
            pass
        else:
            _replace(path.with_name(path.name + '.bak'), previous)
    _replace(path, payload)
    if not path.with_name(path.name + '.bak').exists():
        _replace(path.with_name(path.name + '.bak'), payload)


def load_json(path):
    path = Path(path)
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (ValueError, UnicodeError) as original:
        backup = path.with_name(path.name + '.bak')
        try:
            payload = backup.read_text(encoding='utf-8-sig')
            result = json.loads(payload)
        except (OSError, ValueError, UnicodeError):
            raise ValueError('JSON data corrupted and no valid backup: ' + path.name) from original
        shutil.copy2(path, path.with_name(path.name + '.corrupt-' + uuid.uuid4().hex))
        _replace(path, payload)
        return result
